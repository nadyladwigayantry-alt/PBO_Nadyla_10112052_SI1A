<?php
require_once __DIR__ . '/Database.php';

class Gudang extends Database {
    public function tampil_data() {
        $data = [];
        $query = "SELECT * FROM gudang ORDER BY id_gudang";
        $result = $this->koneksi->query($query);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
        }
        return $data;
    }

    public function tambah_data($kode_gudang, $nama_gudang, $lokasi) {
        $kode_gudang = $this->koneksi->real_escape_string($kode_gudang);
        $nama_gudang = $this->koneksi->real_escape_string($nama_gudang);
        $lokasi = $this->koneksi->real_escape_string($lokasi);

        $query = "INSERT INTO gudang (kode_gudang, nama_gudang, lokasi) VALUES ('$kode_gudang', '$nama_gudang', '$lokasi')";
        return $this->koneksi->query($query);
    }

    public function get_data_by_id($id_gudang) {
        $id_gudang = (int)$id_gudang;
        $query = "SELECT * FROM gudang WHERE id_gudang=$id_gudang";
        $result = $this->koneksi->query($query);
        return $result ? $result->fetch_assoc() : null;
    }

    public function edit_data($id_gudang, $kode_gudang, $nama_gudang, $lokasi) {
        $id_gudang = (int)$id_gudang;
        $kode_gudang = $this->koneksi->real_escape_string($kode_gudang);
        $nama_gudang = $this->koneksi->real_escape_string($nama_gudang);
        $lokasi = $this->koneksi->real_escape_string($lokasi);

        $query = "UPDATE gudang SET kode_gudang='$kode_gudang', nama_gudang='$nama_gudang', lokasi='$lokasi' WHERE id_gudang=$id_gudang";
        return $this->koneksi->query($query);
    }

    public function hapus_data($id_gudang) {
        $id_gudang = (int)$id_gudang;
        $query = "DELETE FROM gudang WHERE id_gudang=$id_gudang";
        return $this->koneksi->query($query);
    }
}
?>